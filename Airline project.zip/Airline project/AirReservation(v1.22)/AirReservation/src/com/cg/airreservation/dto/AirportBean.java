package com.cg.airreservation.dto;

public class AirportBean {

	private String airportZip;
	private String airportName;
	private String airportAbbv;
	private String airportLocation;
	
	
	public AirportBean() {
		super();
	}
	public String getAirportZip() {
		return airportZip;
	}
	public void setAirportZip(String airportZip) {
		this.airportZip = airportZip;
	}
	public String getAirportName() {
		return airportName;
	}
	public void setAirportName(String airportName) {
		this.airportName = airportName;
	}
	public String getAirportAbbv() {
		return airportAbbv;
	}
	public void setAirportAbbv(String airportAbbv) {
		this.airportAbbv = airportAbbv;
	}
	public String getAirportLocation() {
		return airportLocation;
	}
	public void setAirportLocation(String airportLocation) {
		this.airportLocation = airportLocation;
	}
	@Override
	public String toString() {
		return "AirportBean [airportZip=" + airportZip + ", airportName="
				+ airportName + ", airportAbbv=" + airportAbbv
				+ ", airportLocation=" + airportLocation + "]";
	}
	
	
	
}

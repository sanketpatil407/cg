--to understand datatypes in pl sql 

declare

empnum number;
empname varchar2(20);
gender char(1);
onbench boolean ; -- not available in sql 
height number(2,1);
dob date;


begin
empnum:=&empno;
empname:='&name';
gender:='&gender';
onbench:=&onbench;
height:=&ht;
dob:='&dateofbirth';

dbms_output.put_line('num is ' || empnum);
dbms_output.put_line('name is ' || empname);
dbms_output.put_line('gender is ' || gender);
--dbms_output.put_line('onbench value is ' || onbench);--u cannot --print boolean value 


if onbench = true then 

dbms_output.put_line('emp is on bench');
else
dbms_output.put_line('emp is not on bench');
end if;

dbms_output.put_line('dob is ' || dob);
dbms_output.put_line('height is ' || height);

end;
/
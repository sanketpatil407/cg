package com.cg.airreservation.dto;

/**
 * <AirLine Reservation System>
 * All the information after Customer Registration will be store using this class properties.
 */
import java.time.LocalDate;

//Class Name CustomerInfoBean for table CUSTOMER_INFO
public class CustomerInfoBean {

	//Declaring properties
	private int custId;
	private String custName;
	private String userType;
	private LocalDate datOfBirth;
	private String password;
	private String mobileno;
	private String email;
	private String gender;

	//Default constructor
	public CustomerInfoBean() {
	}

	//Getter and setter for above properties
	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public LocalDate getDatOfBirth() {
		return datOfBirth;
	}

	public void setDatOfBirth(LocalDate datOfBirth) {
		this.datOfBirth = datOfBirth;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getMobileno() {
		return mobileno;
	}

	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

}

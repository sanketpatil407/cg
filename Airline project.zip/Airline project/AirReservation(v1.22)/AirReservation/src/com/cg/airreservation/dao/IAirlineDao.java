package com.cg.airreservation.dao;

/**
 * 	<AirLine Reservation System>
 *	Interface for declaring Airlinedao class methods, Class which is for customer operations
 */
import java.time.LocalDate;
import java.util.ArrayList;

import com.cg.airreservation.dto.BookingBean;
import com.cg.airreservation.dto.CustomerInfoBean;
import com.cg.airreservation.dto.FlightBean;
import com.cg.airreservation.exception.AirlineException;

public interface IAirlineDao {

	/*
	 * declaring method, this is used to insert customer and flight info after
	 * confirming booking
	 */
	public boolean insertPassengerInfo(BookingBean bean, FlightBean fBean)
			throws AirlineException; // inserting passenger info

	/*
	 * declaring method, used to calculate total amount (including service tax
	 * and seat fare based on type)
	 */
	public double calFare(BookingBean bean, FlightBean fBean)
			throws AirlineException;

	/*
	 * declaring method, used to fetch all flight information based on date of
	 * journey entered by customer
	 */
	public ArrayList<FlightBean> searchFlight(LocalDate dateJourney)
			throws AirlineException;

	/*
	 * declaring method, used to insert customer details after successful
	 * registration
	 */
	public boolean insertdetails(CustomerInfoBean bean) throws AirlineException;

	/*
	 * declaring method, used to authenticate customer, admin and executive
	 * information during login
	 */
	public CustomerInfoBean checkcredentials(String email, String password)
			throws AirlineException;

}

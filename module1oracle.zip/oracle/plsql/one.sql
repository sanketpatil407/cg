begin

null;
--atleast one executable line has to be written between begin and end otherwise compilation error
end;
/
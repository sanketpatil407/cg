--accept age from the user and detmine whether eligible to vote or not 

declare

age number:=&age;

begin

if age>=18 then 
dbms_output.put_line(' eligible to vote');
else
dbms_output.put_line('not eligible to vote');
end if;

end;
/
--writing select command within pl sql 

declare

var_empno number(4):=&empnum;
var_sal number;

begin

select empno,sal into var_empno,var_sal from emp where empno=var_empno;

dbms_output.put_line(var_empno || 'earns ' || var_sal);
exception 

when no_data_found then 

	dbms_output.put_line(var_empno || ' not found in table ');

when value_error then 
	dbms_output.put_line(var_empno || 'too large.. enter 4 digits only ');
end;
/
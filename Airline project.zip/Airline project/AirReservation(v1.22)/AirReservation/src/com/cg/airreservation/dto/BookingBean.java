package com.cg.airreservation.dto;
/**
 * <AirLine Reservation System>
 * All the information after booking confirmation will be store using this class properties.
*/
import java.sql.Date;
import java.time.LocalDate;
import java.time.LocalTime;

//Class Name BookingBean for table BOOKING_INFO
public class BookingBean {
	
	//Declaring properties
	private int pnr;
	private String flightNo;
	private int custId;
	private String custMobile;
	private String custMail;
	private int passengerNum;
	private String classType;
	private double totalFare;
	private int seatNum;
	private String source;
	private String dest;
	private LocalDate dateOfJourney;
	private LocalTime bookTime;

	//Default Constructor
	public BookingBean() {
		super();
	}

	//Parameterized Constructor
	public BookingBean(int pnr, String flightNo, int custId,
			String custMobile, String custMail, int passengerNum,
			String classType,  double totalFare,
			int seatNum, String source, String dest, LocalDate dateOfJourney,
			LocalTime bookTime) {
		super();
		this.pnr = pnr;
		this.flightNo = flightNo;
		this.custId = custId;
		this.custMobile = custMobile;
		this.custMail = custMail;
		this.passengerNum = passengerNum;
		this.classType = classType;
		this.totalFare = totalFare;
		this.seatNum = seatNum;
		this.source = source;
		this.dest = dest;
		this.dateOfJourney = dateOfJourney;
		this.bookTime = bookTime;
	}

	//Getter and Setters for the above properties
	public int getPnr() {
		return pnr;
	}

	public void setPnr(int pnr) {
		this.pnr = pnr;
	}

	public String getFlightNo() {
		return flightNo;
	}

	public void setFlightNo(String flightNo) {
		this.flightNo = flightNo;
	}

	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	public String getCustMobile() {
		return custMobile;
	}

	public void setCustMobile(String custMobile) {
		this.custMobile = custMobile;
	}

	public String getCustMail() {
		return custMail;
	}

	public void setCustMail(String custMail) {
		this.custMail = custMail;
	}

	public int getPassengerNum() {
		return passengerNum;
	}

	public void setPassengerNum(int passengerNum) {
		this.passengerNum = passengerNum;
	}

	public String getClassType() {
		return classType;
	}

	public void setClassType(String classType) {
		this.classType = classType;
	}

	

	public double getTotalFare() {
		return totalFare;
	}

	public void setTotalFare(double totalFare) {
		this.totalFare = totalFare;
	}

	public int getSeatNum() {
		return seatNum;
	}

	public void setSeatNum(int seatNum) {
		this.seatNum = seatNum;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDest() {
		return dest;
	}

	public void setDest(String dest) {
		this.dest = dest;
	}

	public LocalDate getDateOfJourney() {
		return dateOfJourney;
	}

	public void setDateOfJourney(LocalDate dateOfJourney) {
		this.dateOfJourney = dateOfJourney;
	}

	public LocalTime getBookTime() {
		return bookTime;
	}

	public void setBookTime(LocalTime bookTime) {
		this.bookTime = bookTime;
	}

	//ToString method for properties
	@Override
	public String toString() {
		return "BookingBean [pnr=" + pnr + ", flightNo=" + flightNo
				+ ", custId=" + custId + ", custMobile=" + custMobile
				+ ", custMail=" + custMail + ", passengerNum=" + passengerNum
				+ ", classType=" + classType
				+ ", totalFare=" + totalFare + ", seatNum=" + seatNum
				+ ", source=" + source + ", dest=" + dest + ", dateOfJourney="
				+ dateOfJourney + ", bookTime=" + bookTime + "]";
	}

}

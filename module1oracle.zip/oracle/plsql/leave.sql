declare

cursor mycursor is select leave_end_date,leave_start_date from leave_details where employee_id=&empnum;

var_stdt date;

var_enddt date;
days number:=0;

begin

open mycursor;


loop
fetch mycursor into var_enddt,var_stdt;


exit when mycursor%notfound;
days:=days+(var_enddt-var_stdt);

--dbms_output.put_line(days);


end loop;

dbms_output.put_line(' total days' || days);

close mycursor;
end;
/
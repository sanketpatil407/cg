package com.cg.airreservation.service;

/**
 * <AirLine Reservation System>
 * class for implementing service interface methods i.e AirlineService methods 
 */
import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;

import com.cg.airreservation.dao.IAirlineDao;
import com.cg.airreservation.dao.AirlineDaoImpl;
import com.cg.airreservation.dao.ExecutiveDaoImpl;
import com.cg.airreservation.dao.IExecutiveDao;
import com.cg.airreservation.dto.BookingBean;
import com.cg.airreservation.dto.CustomerInfoBean;
import com.cg.airreservation.dto.FlightBean;
import com.cg.airreservation.exception.AirlineException;

public class AirlineServiceImpl implements IAirlineService {

	// declaring variables
	IAirlineDao dao;

	// default constructor
	public AirlineServiceImpl() {
		dao = new AirlineDaoImpl();
	}

	public void setDao(IAirlineDao dao)
	{
		this.dao=dao;
	}
	/*
	 * This method definition used to book tickets using flight information by
	 * Customer
	 */
	@Override
	public boolean insertPassengerInfo(BookingBean bean, FlightBean fBean)
			throws AirlineException {
		// TODO Auto-generated method stub
		return dao.insertPassengerInfo(bean, fBean);
	}

	/*
	 * this method definition is used to calculate total amount for booked
	 * tickets
	 */
	@Override
	public double calFare(BookingBean bean, FlightBean fBean)
			throws AirlineException {

		return dao.calFare(bean, fBean);
	}

	// This method definition used to register a new Customer
	@Override
	public boolean insertdetails(CustomerInfoBean bean) throws AirlineException {
		// TODO Auto-generated method stub
		return dao.insertdetails(bean);
	}

	// This method definition used to authenticate customer,admin and executive
	@Override
	public CustomerInfoBean checkcredentials(String email, String password)
			throws AirlineException {
		// TODO Auto-generated method stub
		return dao.checkcredentials(email, password);
	}

	/*
	 * This method definition used to fetch flight info based on date entered by
	 * customer
	 */
	@Override
	public ArrayList<FlightBean> searchFlight(LocalDate dateJourney)
			throws AirlineException {
		// TODO Auto-generated method stub
		return dao.searchFlight(dateJourney);
	}

	// this is used to validate customer name
	@Override
	public boolean validateUser(String name) {
		// TODO Auto-generated method stub
		return (name.matches("(^([A-Z]{1}[a-zA-Z]{1,24})[\\s]?([A-Z]{1}[a-zA-Z]{1,23})?$)"));
	}

	// this is used to validate email id of customer
	@Override
	public boolean validateEmail(String email) {
		// TODO Auto-generated method stub
		return email
				.matches("(^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,}))$");
	}

	// this is used to validate customer mobile number
	@Override
	public boolean validateMobile(String mobile) {
		// TODO Auto-generated method stub
		return mobile.matches("[7-9]{1}[0-9]{9}");
	}

	// this is used to validate date of birth
	@Override
	public boolean validateDate(LocalDate date) {
		// TODO Auto-generated method stub
		LocalDate today = LocalDate.now();
		Period diff = date.until(today);

		if (diff.getDays() < 0 || diff.getMonths() < 0 || diff.getYears() < 0) {

			return false;
		}

		if (diff.getDays() <= 0 && diff.getMonths() <= 0
				&& diff.getYears() <= 0) {

			return false;
		}

		return true;
	}

	// this is used to validate customer password
	@Override
	public boolean validatePass(String password) {
		// TODO Auto-generated method stub

		return password
				.matches("^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+_])(?=\\S+$).{8,15}$");

	}

	// this is used to check date pattern
	@Override
	public boolean checkDate(String date) {
		// TODO Auto-generated method stub
		return date
				.matches("(0[1-9]|[12][0-9]|3[01])/(0[1-9]|1[012])/((19|20)\\d\\d)");
	}

	public boolean checkChoice(int choice) {
		String strChoice = String.valueOf(choice);
		return strChoice.matches("[0-9]{1}");
	}
	// this is used to validate Flight Number
	@Override
	public boolean validateFlightNumber(String flightNumber) {
		// TODO Auto-generated method stub
		return flightNumber.matches("[A-Za-z0-9]{1,10}");
	}

	// this is used to validate Flight Name
	@Override
	public boolean validateFlightName(String flightName) {
		// TODO Auto-generated method stub
		return (flightName.matches("^([A-Z]{1}[a-zA-Z\\s][a-zA-Z]*$)"));
	}

	// this is used to validate Flight Amount
	@Override
	public boolean validateFlightAmount(double flightAmount) {
		// TODO Auto-generated method stub
		String flyAmount =String.valueOf(flightAmount); 
		return flyAmount.matches("[0-9]{1,8}\\.[0-9]{0,2}");
	}

	public boolean validateGender(String gender)
	{
		if(!gender.equals("MALE") && !gender.equals("FEMALE"))
			return false;
		
		return true;
	}
	
}

package com.cg.airreservation.dao;

/**
 * <AirLine Reservation System>
 * class for implementing AirlineDao interface methods for customer operations
 */
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import com.cg.airreservation.dbutil.DBUtil;
import com.cg.airreservation.dto.BookingBean;
import com.cg.airreservation.dto.CustomerInfoBean;
import com.cg.airreservation.dto.FlightBean;
import com.cg.airreservation.exception.AirlineException;

public class AirlineDaoImpl implements AirlineDao {

	// declaring variable
	Connection con;

	// defualt constructor
	public AirlineDaoImpl() {
		// TODO Auto-generated constructor stub
		con = DBUtil.getConnection();
	}

	/*
	 * defining method, with the help of this customers can select the type of
	 * class in which they wants to travel
	 */
	@Override
	public double selectClassType(String type) throws AirlineException {
		// TODO Auto-generated method stub

		double charge = 0;
		String selectCharge = "SELECT charge FROM CLASSTYPE WHERE TYPE=?";
		try {
			PreparedStatement pstmt = con.prepareStatement(selectCharge);
			pstmt.setString(1, type);
			ResultSet result = pstmt.executeQuery();
			if (result.next()) {
				charge = result.getDouble(1);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new AirlineException("Exception while fetching charges");
		}

		return charge;
	}

	// remove
	public int getSequence() throws AirlineException {
		int sequence = 0;
		String sql = "SELECT pnr_seq.nextval FROM DUAL";
		Statement stmt;
		try {
			stmt = con.createStatement();
			ResultSet result = stmt.executeQuery(sql);
			if (result.next()) {
				sequence = result.getInt(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new AirlineException(e.getMessage());
		}
		return sequence;
	}

	/*
	 * defining method, this is used to insert customer and flight info after
	 * confirming booking
	 */
	@Override
	public boolean insertPassengerInfo(BookingBean bean, FlightBean fBean)
			throws AirlineException {
		// TODO Auto-generated method stub

		/* Inserting into Booking table */
		boolean flag = false;
		int sequenceNum = getSequence();
		bean.setPnr(sequenceNum);
		String insertBInfo = "INSERT INTO BOOKING_INFO VALUES(?,?,?,?,?,?,?,?,?,?,?,?)";
		try {
			PreparedStatement pstmt = con.prepareStatement(insertBInfo);
			pstmt.setInt(1, sequenceNum);
			pstmt.setString(2, bean.getFlightNo());
			pstmt.setInt(3, bean.getCustId());
			pstmt.setString(4, bean.getCustMobile());
			pstmt.setString(5, bean.getCustMail());
			pstmt.setInt(6, bean.getPassengerNum());
			pstmt.setString(7, bean.getClassType());
			pstmt.setDouble(8, bean.getTotalFare());
			pstmt.setString(9, bean.getSource());
			pstmt.setString(10, bean.getDest());
			pstmt.setDate(11, bean.getDateOfJourney());
			pstmt.setTime(12, Time.valueOf(LocalTime.now()));

			int row = pstmt.executeUpdate();
			if (row != 0) {
				flag = true;
				updateFlight(bean.getPassengerNum(), bean.getClassType(),
						bean.getFlightNo());
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new AirlineException("Exception while inserting flight info");

		}
		return flag;

	}

	/*
	 * defining method, used to update flight information after successful
	 * booking
	 */
	public void updateFlight(int number, String classType, String flightNum)
			throws AirlineException {
		if (classType.equals("A")) {
			String sql = "UPDATE FLIGHT_INFO SET REMAINING_BUSINESS_SEAT=REMAINING_BUSINESS_SEAT-? WHERE FLIGHT_NUM=? ";
			try {
				PreparedStatement pstmt = con.prepareStatement(sql);
				pstmt.setInt(1, number);
				pstmt.setString(2, flightNum);
				int row = pstmt.executeUpdate();

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else if (classType.equals("B")) {

			String sql = "UPDATE FLIGHT_INFO SET REMAINING_ECONOMY_SEAT=REMAINING_ECONOMY_SEAT-? WHERE FLIGHT_NUM=? ";
			try {
				PreparedStatement pstmt = con.prepareStatement(sql);
				pstmt.setInt(1, number);
				pstmt.setString(2, flightNum);
				int row = pstmt.executeUpdate();

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				throw new AirlineException(e.getMessage());
			}

		}

	}

	/*
	 * defining method, used to calculate total amount (including service tax
	 * and seat fare based on type)
	 */
	@Override
	public double calFare(BookingBean bean, FlightBean fBean)
			throws AirlineException {
		// TODO Auto-generated method stub

		// ArrayList<Double> list = new ArrayList<Double>();

		double fare = 0;
		double tax = 0;

		// System.out.println(bean.getClassType());
		if (bean.getClassType().equals("A")) {
			// System.out.println("in A");
			// System.out.println(fBean.getBusiness_fare());
			fare = (bean.getPassengerNum()) * (fBean.getBusiness_fare());
			// System.out.println(fare);
			tax = fare * 0.12;
		}

		else if (bean.getClassType().equals("B")) {
			/*
			 * System.out.println("in B");
			 * System.out.println(fBean.getEconomy_fare());
			 * System.out.println(bean.getPassengerNum());
			 */
			fare = (bean.getPassengerNum()) * (fBean.getEconomy_fare());

			tax = fare * 0.12;
		}
		double totalFare = fare + tax;
		bean.setTotalFare(totalFare);
		return totalFare;
	}

	/*
	 * defining method, used to insert customer details after successful
	 * registration
	 */
	@Override
	public boolean insertdetails(CustomerInfoBean bean) throws AirlineException {
		// TODO Auto-generated method stub
		boolean flag = false;
		String sql = "INSERT INTO CUSTOMER_INFO VALUES(cust_id.nextval,?,?,?,?,?,?,'customer')";
		try {
			PreparedStatement pstate = con.prepareStatement(sql);
			pstate.setString(1, bean.getCustName());
			pstate.setDate(2, Date.valueOf(bean.getDatOfBirth()));
			pstate.setString(3, bean.getPassword());
			pstate.setString(4, bean.getMobileno());
			pstate.setString(5, bean.getEmail());

			pstate.setString(6, bean.getGender());

			int row = pstate.executeUpdate();
			if (row == 0) {
				System.out.println("Unable to Insert Data");
			} else {
				System.out.println("Successfully Inserted");
				flag = true;
			}

		} catch (SQLException e) {
			throw new AirlineException(e.getMessage());
		}
		return flag;
	}

	/*
	 * defining method, used to authenticate customer, admin and executive
	 * information during login
	 */
	@Override
	public CustomerInfoBean checkcredentials(String email, String password)
			throws AirlineException {
		// TODO Auto-generated method stub

		CustomerInfoBean bean = null;
		String sql = "SELECT * FROM Customer_info WHERE CUST_EMAIL=?";
		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(1, email);

			ResultSet result = pstmt.executeQuery();
			if (result.next()) {
				bean = new CustomerInfoBean();
				bean.setCustId(result.getInt(1));
				bean.setCustName(result.getString(2));
				bean.setDatOfBirth((result.getDate(3)).toLocalDate());
				bean.setPassword(result.getString(4));
				bean.setMobileno(result.getString(5));
				bean.setEmail(result.getString(6));
				// bean.setCustName(result.getString("CUST_NAME"));
				bean.setGender(result.getString(7));
				bean.setUserType(result.getString(8));

				if (!bean.getPassword().equals(password)) {
					return null;

				}
			}

		} catch (SQLException e) {
			throw new AirlineException(e.getMessage());
		}
		return bean;
	}

	/*
	 * defining method, used to fetch all flight information based on date of
	 * journey entered by customer
	 */
	@Override
	public ArrayList<FlightBean> searchFlight(LocalDate dateJourney)
			throws AirlineException {
		// TODO Auto-generated method stub
		ArrayList<FlightBean> flightList = new ArrayList<FlightBean>();
		try {
			String sql = "SELECT * FROM FLIGHT_INFO WHERE SCH_DEPRT_TIME like ?";
			PreparedStatement pstmt = con.prepareStatement(sql);
			// pstmt.setString(1,"%"+Date.valueOf(dateJourney)+"%");
			// long date=dateJourney.set
			Date date = Date.valueOf(dateJourney);
			// System.out.println(date);
			pstmt.setDate(1, date);
			// pstmt.setString(1, "%"+"30-JUN-17"+"%");
			ResultSet result = pstmt.executeQuery();
			while (result.next()) {
				FlightBean flightBean = new FlightBean();
				flightBean.setFlightNum(result.getString(1));
				flightBean.setAirlineName(result.getString(2));
				flightBean.setAirport_zip(result.getString(3));
				flightBean.setSource(result.getString(4));
				flightBean.setDestination(result.getString(5));
				flightBean.setBusiness_fare(result.getInt(6));
				flightBean.setEconomy_fare(result.getInt(7));
				flightBean.setBusiness_seats(result.getInt(8));
				flightBean.setEconomy_seats(result.getInt(9));
				flightBean.setDeptDate(result.getDate(10));
				flightBean.setArriveDate(result.getDate(11));
				flightBean.setArriveTime(result.getString(12));
				flightBean.setDeptTime(result.getString(13));
				flightBean.setRemainingBusSeats(result.getInt(14));
				flightBean.setRemainingEcoSeats(result.getInt(15));
				// flightBean.setArriveTime((result.getTime(8)).toLocalTime());
				// flightBean.setDeptTime(result.getTime(9).toLocalTime());
				flightList.add(flightBean);
				// System.out.println(flightList.size());
			}

		} catch (Exception e) {
			throw new AirlineException(e.getMessage());
		}
		return flightList;
	}

}

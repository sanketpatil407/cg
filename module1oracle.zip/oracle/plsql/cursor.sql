--concept of cursors
declare


cursor mycursor is select empno,sal from emp ;
var_empno emp.empno%type;



var_sal emp.sal%type;

begin

open mycursor;
loop
fetch mycursor into var_empno,var_sal;
dbms_output.put_line(var_empno  || '    ' 
||  var_sal);
exit when mycursor%notfound;
end loop;

close mycursor;

end;
/
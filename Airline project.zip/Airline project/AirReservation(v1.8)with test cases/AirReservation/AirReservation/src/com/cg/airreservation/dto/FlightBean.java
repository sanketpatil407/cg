package com.cg.airreservation.dto;

/**
 * <AirLine Reservation System>
 * All the information after Adding New Flight will be store using this class properties.
 */
import java.sql.Date;
import java.time.LocalTime;

//Class Name FlightBean for table FLIGHT_INFO
public class FlightBean {

	// Declaring Properties
	private String flightNum;
	private String airlineName;
	private String airport_zip;
	private String source;
	private String destination;
	private double business_fare;
	private double economy_fare;
	private int business_seats;
	private int economy_seats;
	private Date deptDate;
	private Date arriveDate;
	private String deptTime; // temp then change to below variable declared
	private String arriveTime;
	private int remainingEcoSeats;
	private int remainingBusSeats;

	// private LocalTime deptTime;
	// private LocalTime arriveTime;

	// Default constructor
	public FlightBean() {
		super();
	}

	// parameterized Constructor
	public FlightBean(String flightNum, String airlineName, String source,
			String destination, Date deptDate, Date arriveDate,
			String deptTime, String arriveTime) {
		super();
		this.flightNum = flightNum;
		this.airlineName = airlineName;
		this.source = source;
		this.destination = destination;
		this.deptDate = deptDate;
		this.arriveDate = arriveDate;

		this.deptTime = deptTime;
		this.arriveTime = arriveTime;
	}

	// Getter and Setter for above properties
	public int getRemainingEcoSeats() {
		return remainingEcoSeats;
	}

	public void setRemainingEcoSeats(int remainingEcoSeats) {
		this.remainingEcoSeats = remainingEcoSeats;
	}

	public int getRemainingBusSeats() {
		return remainingBusSeats;
	}

	public void setRemainingBusSeats(int remainingBusSeats) {
		this.remainingBusSeats = remainingBusSeats;
	}

	public String getFlightNum() {
		return flightNum;
	}

	public void setFlightNum(String flightNum) {
		this.flightNum = flightNum;
	}

	public String getAirlineName() {
		return airlineName;
	}

	public void setAirlineName(String airlineName) {
		this.airlineName = airlineName;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public Date getDeptDate() {
		return deptDate;
	}

	public void setDeptDate(Date deptDate) {
		this.deptDate = deptDate;
	}

	public Date getArriveDate() {
		return arriveDate;
	}

	public void setArriveDate(Date arriveDate) {
		this.arriveDate = arriveDate;
	}

	public String getDeptTime() {
		return deptTime;
	}

	public void setDeptTime(String deptTime) {
		this.deptTime = deptTime;
	}

	public String getArriveTime() {
		return arriveTime;
	}

	public void setArriveTime(String arriveTime) {
		this.arriveTime = arriveTime;
	}

	public String getAirport_zip() {
		return airport_zip;
	}

	public void setAirport_zip(String airport_zip) {
		this.airport_zip = airport_zip;
	}

	public double getBusiness_fare() {
		return business_fare;
	}

	public void setBusiness_fare(double business_fare) {
		this.business_fare = business_fare;
	}

	public double getEconomy_fare() {
		return economy_fare;
	}

	public void setEconomy_fare(double economy_fare) {
		this.economy_fare = economy_fare;
	}

	public int getBusiness_seats() {
		return business_seats;
	}

	public void setBusiness_seats(int business_seats) {
		this.business_seats = business_seats;
	}

	public int getEconomy_seats() {
		return economy_seats;
	}

	public void setEconomy_seats(int economy_seats) {
		this.economy_seats = economy_seats;
	}

	// ToString Method for above properties
	@Override
	public String toString() {
		return "FlightBean [flightNum=" + flightNum + ", airlineName="
				+ airlineName + ", source=" + source + ", destination="
				+ destination + ", deptDate=" + deptDate + ", arriveDate="
				+ arriveDate + ", deptTime=" + deptTime + ", arriveTime="
				+ arriveTime + "]";
	}
}

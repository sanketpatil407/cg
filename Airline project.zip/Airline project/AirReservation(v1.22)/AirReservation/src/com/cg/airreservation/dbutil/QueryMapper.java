package com.cg.airreservation.dbutil;

public interface QueryMapper {

	/* For Customer Section*/
	String getPnrSequence = "SELECT pnr_seq.nextval FROM DUAL";
	String insertpassengerInfo = "INSERT INTO BOOKING_INFO VALUES(?,?,?,?,?,?,?,?,?,?,?,?)";
	String updateFlightInfoBuss = "UPDATE FLIGHT_INFO SET REMAINING_BUSINESS_SEAT=REMAINING_BUSINESS_SEAT-? WHERE FLIGHT_NUM=? ";
	String updateFlightInfoEco = "UPDATE FLIGHT_INFO SET REMAINING_ECONOMY_SEAT=REMAINING_ECONOMY_SEAT-? WHERE FLIGHT_NUM=? ";
	String insertCustomerDetails = "INSERT INTO CUSTOMER_INFO VALUES(cust_id.nextval,?,?,?,?,?,?,'customer') ";
	String checkCredentials = "SELECT * FROM Customer_info WHERE CUST_EMAIL=?";
	String searchFlightByDate = "SELECT * FROM FLIGHT_INFO WHERE SCH_DEPRT_TIME like ?";
	
	/* For Admin & Executive Section*/
	
	String flightOccupacyDetails ="SELECT * FROM FLIGHT_INFO WHERE FLIGHT_NUM=?";
	String addFlightInfo ="INSERT INTO FLIGHT_INFO VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	String generateFlightList = "SELECT * FROM FLIGHT_INFO WHERE SCH_DEPRT_TIME like ?";
	String fetchPassengerList = "SELECT * FROM BOOKING_INFO WHERE FLIGHT_NUM=?";
	String fetchAirportList= "SELECT * FROM AIRPORT_INFO";
}

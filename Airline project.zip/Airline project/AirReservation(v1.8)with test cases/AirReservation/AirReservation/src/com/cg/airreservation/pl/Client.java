package com.cg.airreservation.pl;

/**
 * <AirLine Reservation System>
 *	This class containing the main method and used to provide UI to end users
 */
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Date;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;

import com.cg.airreservation.dto.BookingBean;
import com.cg.airreservation.dto.CustomerInfoBean;
import com.cg.airreservation.dto.FlightBean;
import com.cg.airreservation.exception.AirlineException;
import com.cg.airreservation.service.AirlineService;
import com.cg.airreservation.service.AirlineServiceImpl;

public class Client {

	// creating object of Airline service class
	static AirlineService service = new AirlineServiceImpl();

	@SuppressWarnings("resource")
	/** main method */
	public static void main(String[] args) {

		// declaring variables
		int homeChoice;
		int searchChoice = 0;

		// creating object of scanner
		Scanner scan = new Scanner(System.in);

		// first try(1) with resources
		try (BufferedReader reader = new BufferedReader(new InputStreamReader(
				System.in))) {
			// starting of homepage do while(1)
			do {
				System.out.println("*********AirLine Reservation***********");
				System.out.println();
				System.out.println("Please Select Your Choice::\n");

				System.out.println("1. SignUp\n2.Login\n3.Exit");

				homeChoice = Integer.parseInt(reader.readLine());

				// start of homepage switch(1)
				switch (homeChoice) {

				case 1:
					signUp();
					break;

				case 2:
					login();
					break;

				case 3:
					System.exit(0);
					break;
				default:
					System.out
							.println(" Not valid choice..Please Enter valid choice");
				} // end of homepage switch(1)

				/*
				 * start of do while(2) for handling any other option in home
				 * page
				 */
				do {
					System.out.println("want to go at HomePage 1-Yes & 0-No");
					searchChoice = scan.nextInt();
					if (searchChoice != 1 && searchChoice != 0)
						System.out
								.println("Not valid option.Please select correct option.");
				} while (searchChoice != 1 && searchChoice != 0);
				/* end of do while(2) for handling any other option in home page */

			} while (searchChoice != 0); // end of do while page(1)

			System.out.println("Thank you..Exit...");

		} catch (Exception e) { // end of try
			// e.printStackTrace();
			System.out.println(e.getMessage());
		}

	} // end of main method

	/** SignUp method */
	private static void signUp() throws IOException, AirlineException {
		/* start of sign up method */
		BufferedReader reader = new BufferedReader(new InputStreamReader(
				System.in));
		System.out
				.println("Welcome To AirLine Reservation.\n Please Enter Your Details");
		boolean custNameFlag = false;
		String name;
		String mail;
		do { // start of do while for name exception(3)
			System.out.println("Enter Your Name :");
			name = reader.readLine();
			custNameFlag = service.validateUser(name);
			if (!custNameFlag)
				System.out
						.println("Invalid User name. First letter should be capital..");
		} while (!custNameFlag); // end of do while(3) for name exception

		boolean custMailFlag = false;
		do { // start of do while for mail exception(4)
			System.out.println("Enter Your Mail Id :");
			mail = reader.readLine();
			custMailFlag = service.validateEmail(mail);
			if (!custMailFlag)
				System.out
						.println("Invalid Email id. please enter valid email (abc@gmail.com)..");
		} while (!custMailFlag); // end of do while for mail exception(4)

		boolean dateFlag = false;
		LocalDate date;
		String input;
		DateTimeFormatter format;
		do { // start of do while for date of birth after todays date
				// exception(5)
			boolean checkFlag;
			do { // start of do while for date of birth not in format
					// exception(6)
				format = DateTimeFormatter.ofPattern("dd/MM/yyyy");

				System.out.println("Enter Date of Birth (dd/MM/yyyy) :");

				input = reader.readLine();
				checkFlag = service.checkDate(input);

			} while (!checkFlag); // end of do while for date of birth not in
									// format exception(6)
			date = LocalDate.parse(input, format);
			dateFlag = service.validateDate(date);
			if (!dateFlag)
				System.out
						.println("Please Enter Valid Date of Birth. Date Should be before today's Date");
		} while (!dateFlag); // end of do while for date of birth after todays
								// date exception(5)
		String gender;
		do { // start of do while for gender exception(7)
			System.out.println("Enter Gender (Male/Female) :");
			gender = reader.readLine();
			gender = gender.toUpperCase();

			if (!gender.equals("MALE") && !gender.equals("FEMALE"))
				System.out.println("Please enter either Male or Female\n");
		} while (!gender.equals("MALE") && !gender.equals("FEMALE"));
		/* end of do while for gender exception (7) */
		boolean mobileFlag = false;
		String mobile;
		do { // start of do while for mobile number exception(8)
			System.out.println("Enter Mobile Number :");
			mobile = reader.readLine();
			mobileFlag = service.validateMobile(mobile);
			if (!mobileFlag)
				System.out
						.println("Not valid mobile number. Mobile Number must start with 7,8 or 9 and should be 10 digit number");
		} while (!mobileFlag); // end of do while for mobile number exception(8)

		String password = null;
		boolean flag = true;
		boolean passFlag = true;
		while (flag || passFlag) { /*
									 * start of loop while unless password and
									 * re-enter not match and password is in
									 * given pattern
									 */
			System.out.println("Enter Your Password :");
			password = reader.readLine();
			passFlag = service.validatePass(password);
			if (!passFlag) { // check if password is in pattern
				System.out
						.println("Password Not Match! Your password must contain an uppercase letter, a lowercase letter, a special char and a number.");
				passFlag = true;

			} // end of if password is in pattern
			else { // if password is in pattern
				passFlag = false;
				System.out.println("ReEnter Your Password :");
				String rePassword = reader.readLine();

				if (password.equals(rePassword)) { // if password and repassword
													// match
					flag = false;
				} else
					// else if password and repassword not match
					System.out.println("Password mismatch.");

			} // end of else if password is in pattern
		} // end of loop while unless password and re-enter not match and
			// password is in given pattern
		CustomerInfoBean custBean = new CustomerInfoBean();
		custBean.setCustName(name);
		custBean.setEmail(mail);
		custBean.setDatOfBirth(date);
		custBean.setGender(gender);
		custBean.setMobileno(mobile);
		custBean.setPassword(password);
		custBean.setUserType("customer");
		boolean inserFlag = service.insertdetails(custBean);
		if (inserFlag) { // if data inserted successfully
			System.out.println("****Successfully Registered. Thank You!!*****");

		} else { // else if data not inserted
			System.out
					.println("Unable to register. Please Register again. Thank You!!");

		}

	} // end of sign up method

	/** method for admin, executive and customer login*/
	private static void login() throws IOException, AirlineException {

		boolean custValidate;
		do {
			custValidate = false;
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					System.in));
			Scanner scan = new Scanner(System.in);

			System.out.println("***Login***");
			System.out.println("Enter Your Email :");
			String loginEmail = reader.readLine();
			System.out.println("Enter Password :");
			String loginPass = reader.readLine();

			CustomerInfoBean loginBean = service.checkcredentials(loginEmail,
					loginPass);
			if (loginBean != null) {
				System.out.println("Login Successfull");

				switch (loginBean.getUserType()) {
				case "customer":

					customer(loginBean);
					break;

				case "admin":
					admin(loginBean);
					break;

				case "executive":
					executive(loginBean);
					break;

				default:
					System.out.println(" Authentication failed");

				}

			} else {

				System.out.println("Invalid login..");
				boolean invalidChoice = false;
				do {
					System.out.println("1.Login 2.exit");
					int loginChoice = scan.nextInt();
					if (loginChoice == 1) {
						custValidate = true;
						invalidChoice = true;
					} else if (loginChoice == 2)
						break;
					else
						System.out.println("Please Enter valid choice..");
				} while (!invalidChoice);
			}
		} while (custValidate);

	}

	// after customer login
	private static void customer(CustomerInfoBean loginBean)
			throws IOException, AirlineException {

		BufferedReader reader = new BufferedReader(new InputStreamReader(
				System.in));
		Scanner scan = new Scanner(System.in);

		int option = 0;
		do {
			int count = 1;
			System.out.println("Hello " + loginBean.getCustName());
			System.out.println("\nSearch your Flight Here\n");

			DateTimeFormatter formatDoj = DateTimeFormatter
					.ofPattern("dd/MM/yyyy");
			LocalDate journeyDate;
			String dateJourney;
			boolean checkByDate = false;
			int flightCount = 0;
			do {

				do {
					System.out
							.println("Enter date of journey in the form dd/mm/yyyy");
					dateJourney = reader.readLine();

					checkByDate = service.checkDate(dateJourney);
					if (!checkByDate)
						System.out
								.println("Please Enter valid Date in format dd/mm/yyyy");
				} while (!checkByDate);

				journeyDate = LocalDate.parse(dateJourney, formatDoj);
				ArrayList<FlightBean> flightList = service
						.searchFlight(journeyDate);
				// System.out.println(flightList.size());
				ArrayList<FlightBean> noSeatList = new ArrayList<FlightBean>();

				if (flightList.size() != 0) {
					for (FlightBean flightBean : flightList) {
						if (flightBean.getRemainingBusSeats() > 0
								&& flightBean.getRemainingEcoSeats() > 0) {
							flightCount++;
							System.out.print(count++ + ") ");
							System.out.println("Flight Number: "
									+ flightBean.getFlightNum());
							System.out.println("Source city "
									+ flightBean.getSource());
							System.out.println("Destination city "
									+ flightBean.getDestination());
							System.out.println("Departure Time: "
									+ flightBean.getDeptTime());
						}

						else {
							noSeatList.add(flightBean);
						}

					}
					if (flightCount == 0) {
						System.out
								.println(" Not available. Please Select another date of journey..");

						System.out
								.println("\n Seats Full in below Flights.. Sorry...");
						for (FlightBean beanFlight : noSeatList) {
							System.out.println("Flight Number "
									+ beanFlight.getFlightNum());
							System.out.println("Airline Name "
									+ beanFlight.getAirlineName());
							System.out.println("source city "
									+ beanFlight.getSource());
							System.out.println("Destination City "
									+ beanFlight.getDestination());
						}

					}

					// if flight available
					else {
						boolean pathFlag = false;
						int path;
						do {
							System.out.println("\nSelect your journey path");
							path = scan.nextInt();
							if (path < 1 || path > count) {
								System.out
										.println("No such option.. please select valid option..");
								pathFlag = true;
							} else
								pathFlag = false;
						} while (pathFlag);
						FlightBean fBean = flightList.get(path - 1);
						System.out.println("Flight Number: "
								+ fBean.getFlightNum());
						System.out.println("Source: " + fBean.getSource());
						System.out.println("Destination: "
								+ fBean.getDestination());
						System.out
								.println("Seats available in Business Class: "
										+ fBean.getRemainingBusSeats());
						System.out.println("Fare for Business Class: "
								+ fBean.getBusiness_fare());
						System.out.println("Seats available in Economy Class: "
								+ fBean.getRemainingEcoSeats());
						System.out.println("Fare for Economy Class: "
								+ fBean.getEconomy_fare());
						System.out.println("Date of Departure: "
								+ fBean.getDeptDate());
						System.out.println("Time of Departure from Source: "
								+ fBean.getDeptTime());
						System.out.println("Date of Arrival: "
								+ fBean.getArriveDate());
						System.out.println("Time of Arrival to Destination: "
								+ fBean.getArriveTime());
						System.out
								.println("Select class in which you want to travel: (A)Business Class  (B)Economy Class ");

						boolean typeFlag;
						int seats = 0;
						String classType;

						// select class type
						do {
							typeFlag = false;
							System.out.println("Enter your choice: (A/B)");
							classType = scan.next();
							classType = classType.toUpperCase();

							double fare;
							if (classType.equals("A")) {
								seats = fBean.getRemainingBusSeats();
								fare = fBean.getBusiness_fare();
							} else if (classType.equals("B")) {
								seats = fBean.getRemainingEcoSeats();
								fare = fBean.getEconomy_fare();
							} else {
								typeFlag = true;
								System.out.println("Class type not exist");
							}
						} while (typeFlag);

						boolean seatCount;
						int numOfSeats;
						boolean seatFlag = false;
						BookingBean bookBean = null;
						// check entered number of seat less than available
						do {
							seatCount = false;
							System.out
									.println("Enter Number of seats you want to book: ");
							numOfSeats = scan.nextInt();

							if (numOfSeats <= seats && numOfSeats > 0) {
								bookBean = new BookingBean();
								bookBean.setFlightNo(fBean.getFlightNum());
								bookBean.setClassType(classType);
								bookBean.setDateOfJourney(fBean.getDeptDate());
								bookBean.setDest(fBean.getDestination());
								bookBean.setSource(fBean.getSource());
								bookBean.setBookTime(LocalTime.now());
								bookBean.setCustId(loginBean.getCustId());
								bookBean.setCustMail(loginBean.getEmail());
								bookBean.setCustMobile(loginBean.getMobileno());
								bookBean.setClassType(classType);
								bookBean.setPassengerNum(numOfSeats);
								double totalFare = service.calFare(bookBean,
										fBean);
								System.out
										.println("Total Fare For your Trip is "
												+ totalFare);

							}

							else if (numOfSeats > seats) {
								seatCount = true;
								System.out
										.println("Entered seats exceeds the no of seats available ");
							} else {
								seatCount = true;
								System.out
										.println("At least one seat need to be booked ");
							}

						} while (seatCount);

						do {
							System.out
									.println("Select your option \n (1)Book \n (2)Search another flight \n (3)Exit");
							option = scan.nextInt();
							if (option == 1) {

								seatFlag = service.insertPassengerInfo(
										bookBean, fBean);
								if (seatFlag) {

									System.out
											.println("** Thank You For choosing us.Your Booking Confirmed.");

									System.out.println("Your PNR Number is: "
											+ bookBean.getPnr());
									System.out.println("Flight Number :"
											+ bookBean.getFlightNo());

									System.out.println("Customer Email :"
											+ bookBean.getCustMail());
									System.out
											.println("Number of seats booked :"
													+ bookBean
															.getPassengerNum());
									System.out.println("Total Fare :"
											+ bookBean.getTotalFare());

								} else {
									System.out
											.println("Sorry..Booking not Successful.Please Try Again");
								}
							}

							else if (option == 3) {
								System.exit(0);
							} else if (option == 2) {

							} else {
								option = 0;
								System.out
										.println("Please enter Valid Option (1,2,3).");
							}
						} while (option == 0);

					}
				}

				else {
					System.out.println("Not valid date of journey");
				}
			} while (flightCount == 0);

		} while (option == 2);

	}

	// after admin login
	private static void admin(CustomerInfoBean loginBean) throws IOException,
			AirlineException {
		BufferedReader reader = new BufferedReader(new InputStreamReader(
				System.in));
		Scanner scan = new Scanner(System.in);

		System.out.println("***Welcome To AirLine Rservation***");
		System.out.println("Hello Admin..");
		int adminChoice;

		do {
			System.out.println("Enter your Option :");
			System.out
					.println("1.Add new Flight\n2.View Flight List By Date\n3.View Booking List By Flight Number\n4.View Passenger List By Flight Number\n5.exit ");

			adminChoice = scan.nextInt();
			switch (adminChoice) {

			case 1:

				addNewFlight();

				break;

			case 2:
				viewListByDate();

				break;

			case 3:
				viewBookingList();

				break;

			case 4:
				viewPassengerList();

				break;

			case 5:
				System.exit(0);

			default:
				System.out.println("Not valid value");
			}// switch end

			System.out.println("Do you want to continue 1.yes 2.No");
			adminChoice = scan.nextInt();
		} while (adminChoice == 1);

	}

	// after executive login

	private static void executive(CustomerInfoBean loginBean)
			throws AirlineException {

		BufferedReader reader = new BufferedReader(new InputStreamReader(
				System.in));
		Scanner scan = new Scanner(System.in);

		int executiveOption;
		System.out.println("***Welcome To AirLine Rservation***");

		System.out.println("Hello Executive..!!");
		do {
			executiveOption = 0;
			System.out
					.println("* You can check seats availability in flights based on flight number.");
			System.out.println("Enter Flight Number : ");
			String flightNumber = scan.next();
			FlightBean flightBean = service
					.flightOccupancyDetails(flightNumber);
			if (flightBean != null) {
				System.out.println("Flight Number :"
						+ flightBean.getFlightNum());
				System.out.println("AirLine Name :"
						+ flightBean.getAirlineName());
				System.out.println("Total Number Of Buisness Seats :"
						+ flightBean.getBusiness_seats());
				System.out.println("Remaining Number Of Business Seats :"
						+ flightBean.getRemainingBusSeats());
				System.out.println("Total Number Of Economy Seats :"
						+ flightBean.getEconomy_seats());
				System.out.println("Remaining Number Of Economy Seats :"
						+ flightBean.getRemainingEcoSeats());

			} else {
				System.out
						.println("Flight Number not exist.. Please enter valid Flight Number");
			}

			while (executiveOption != 1 && executiveOption != 2) {
				System.out.println("1.Search another flight 2.Exit");
				executiveOption = scan.nextInt();
				if (executiveOption != 1 && executiveOption != 2)
					System.out
							.println("Sorry.. Please Enter correct choice(1 or 2).");

			}

		} while (executiveOption == 1);

	}

	// add new flight
	private static void addNewFlight() throws IOException, AirlineException {
		BufferedReader reader = new BufferedReader(new InputStreamReader(
				System.in));
		Scanner scan = new Scanner(System.in);

		System.out.println("Enter Flight Number: ");
		String flightNum = scan.next();
		System.out.println("Enter Airline name:");
		String airName = reader.readLine();
		System.out.println("Enter Airport Zipcode: ");
		String zipcode = reader.readLine();
		System.out.println("Enter Source City: ");
		String sourceCity = reader.readLine();
		System.out.println("Enter Destination City: ");
		String destinationCity = reader.readLine();
		System.out.println("Enter the fare for Business Class: ");
		Double businessClassFare = scan.nextDouble();
		System.out.println("Enter the fare for Economy Class: ");
		Double economyClassFare = scan.nextDouble();
		System.out.println("Enter the number of seats for Business Class: ");
		int businessClassSeats = scan.nextInt();
		System.out.println("Enter the number of seats for Economy Class: ");
		int economyClassSeats = scan.nextInt();
		System.out.println("Enter Scheduled Departure Date (dd/MM/yyyy): ");
		String schDepartureDate = reader.readLine();
		DateTimeFormatter formatDoj = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate schDepartureDate1 = LocalDate.parse(schDepartureDate,
				formatDoj);
		System.out.println("Enter Scheduled Arrival Date (dd/MM/yyyy): ");
		String schArrivalDate = reader.readLine();
		LocalDate schArrivalDate1 = LocalDate.parse(schArrivalDate, formatDoj);
		System.out.println("Enter Arrival Time in format (hh:mm): ");
		String arrivalTime = reader.readLine();
		System.out.println("Enter Departure Time in format (hh:mm): ");
		String departureTime = reader.readLine();

		FlightBean newFlightBean = new FlightBean();
		newFlightBean.setFlightNum(flightNum);
		newFlightBean.setAirlineName(airName);
		newFlightBean.setAirport_zip(zipcode);
		newFlightBean.setSource(sourceCity);
		newFlightBean.setDestination(destinationCity);
		newFlightBean.setBusiness_fare(businessClassFare);
		newFlightBean.setEconomy_fare(economyClassFare);
		newFlightBean.setBusiness_seats(businessClassSeats);
		newFlightBean.setEconomy_seats(economyClassSeats);
		newFlightBean.setDeptDate(Date.valueOf(schDepartureDate1));
		newFlightBean.setArriveDate(Date.valueOf(schArrivalDate1));
		newFlightBean.setArriveTime(arrivalTime);
		newFlightBean.setDeptTime(departureTime);

		boolean adminFlag = service.insertFlightInfo(newFlightBean);
		// System.out.println(adminFlag);
		if (adminFlag) {
			System.out.println(("Flight added successufully.."));
		} else {
			System.out.println("Unable to insert new Flight");
		}

	}

	// List By date
	private static void viewListByDate() throws IOException, AirlineException {
		BufferedReader reader = new BufferedReader(new InputStreamReader(
				System.in));

		DateTimeFormatter listByDate = DateTimeFormatter.ofPattern("dd/MM/yy");
		System.out.println("Enter date of journey in the form dd/mm/yy");
		String dateJourney = reader.readLine();
		LocalDate flightDate = LocalDate.parse(dateJourney, listByDate);
		ArrayList<FlightBean> flightList = service
				.generateFlightList(flightDate);
		// System.out.println(flightList.size());
		int count = 1;
		if (flightList.size() != 0) {
			for (FlightBean flightBean : flightList) {
				System.out.println(count++ + ") ");
				System.out.print("Flight Number: " + flightBean.getFlightNum());
				System.out.print("Source city " + flightBean.getSource());
				System.out.print("Destination city "
						+ flightBean.getDestination());
				System.out.println("Departure Date :"
						+ flightBean.getDeptDate());
				System.out.print("Departure Time: " + flightBean.getDeptTime());
				System.out.println();

			}

		}

	}

	// booking list by flight number
	private static void viewBookingList() throws AirlineException {
		Scanner scan = new Scanner(System.in);

		System.out
				.println("* You can check seats availability in flights based on flight number.");
		System.out.println("Enter Flight Number : ");
		String flightNumber = scan.next();
		FlightBean flightBean = service.flightOccupancyDetails(flightNumber);
		System.out.println("Flight Number :" + flightBean.getFlightNum());
		System.out.println("AirLine Name :" + flightBean.getAirlineName());
		System.out.println("Total Number Of Buisness Seats :"
				+ flightBean.getBusiness_seats());
		System.out.println("Remaining Number Of Business Seats :"
				+ flightBean.getRemainingBusSeats());
		System.out.println("Total Number Of Economy Seats :"
				+ flightBean.getEconomy_seats());
		System.out.println("Remaining Number Of Economy Seats :"
				+ flightBean.getRemainingEcoSeats());

	}

	// Passenger list by flight number

	private static void viewPassengerList() throws AirlineException {
		Scanner scan = new Scanner(System.in);

		System.out
				.println("* You can check passenger list in flight based on flight number.");
		System.out.println("Enter Flight Number : ");
		String flyNum = scan.next();
		ArrayList<BookingBean> bookList = service.fetchPassengerList(flyNum);

		for (BookingBean bean : bookList) {

			System.out.println("Customer Id :" + bean.getCustId());
			System.out.println("Customer Email :" + bean.getCustMail());
			System.out.println("Customer Mobile :" + bean.getCustMobile());
			System.out.println(("Number of Seats booked :" + bean
					.getPassengerNum()));
		}

	}

}

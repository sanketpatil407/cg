package com.igate.dao;

import java.util.List;

import com.igate.bean.User;

public interface UserDaoIntf {
	public List<User> displayUsers();
}

declare
ctr number:=1;


begin
while ctr<10
loop

dbms_output.put_line(ctr);
ctr:=ctr+1;


end loop;


end;
/
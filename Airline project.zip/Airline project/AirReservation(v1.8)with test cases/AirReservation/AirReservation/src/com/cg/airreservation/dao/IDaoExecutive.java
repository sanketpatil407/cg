package com.cg.airreservation.dao;

/**
 * 	<AirLine Reservation System>
 *	Interface for declaring DaoExecutiveImpl class methods,
 *	 Class which is for admin and executive operations
 */
import java.time.LocalDate;
import java.util.ArrayList;

import com.cg.airreservation.dto.BookingBean;
import com.cg.airreservation.dto.FlightBean;
import com.cg.airreservation.exception.AirlineException;

public interface IDaoExecutive {

	/*
	 * declaring method, used to get information about seat availability based
	 * on flight number by executive
	 */
	public FlightBean flightOccupancyDetails(String flight_num)
			throws AirlineException;

	/*
	 * declaring method, used to Add new flight information by admin
	 */
	public boolean insertFlightInfo(FlightBean bean) throws AirlineException;

	/*
	 * declaring method, used to fetch all flight information based on date of
	 * journey entered by admin
	 */
	public ArrayList<FlightBean> generateFlightList(LocalDate dateJourney)
			throws AirlineException;

	/*
	 * declaring method, used to fetch all the passengers list based on flight
	 * number by admin
	 */
	public ArrayList<BookingBean> fetchPassengerList(String flightNum)
			throws AirlineException;

}

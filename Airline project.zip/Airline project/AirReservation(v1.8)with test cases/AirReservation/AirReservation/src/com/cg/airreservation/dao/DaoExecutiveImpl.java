package com.cg.airreservation.dao;

/**
 * <AirLine Reservation System>
 * class for implementing IDaoExecutive interface methods for admin and executive operations
 */

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;

import com.cg.airreservation.dbutil.DBUtil;
import com.cg.airreservation.dto.BookingBean;
import com.cg.airreservation.dto.FlightBean;
import com.cg.airreservation.exception.AirlineException;



public class DaoExecutiveImpl implements IDaoExecutive{

	//declaring variable 
	Connection con;
	
	//Default constructor
	public DaoExecutiveImpl()
	{
		con = DBUtil.getConnection();
	}
	
	/*
	 * defining method, used to get information about seat availability based
	 * on flight number by executive
	 */
	@Override
	public FlightBean flightOccupancyDetails(String flight_num) throws AirlineException {
		// TODO Auto-generated method stub
		FlightBean bean = null;
		
		try
		{
			String sql = "SELECT * FROM FLIGHT_INFO WHERE FLIGHT_NUM=?";
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(1,flight_num);
			ResultSet result = pstmt.executeQuery();
			if(result.next())
			{
				bean = new FlightBean();
				bean.setFlightNum(result.getString(1));
				bean.setAirlineName(result.getString(2));
				bean.setAirport_zip(result.getString(3));
				bean.setSource(result.getString(4));
				bean.setDestination(result.getString(5));
				bean.setBusiness_fare(result.getDouble(6));
				bean.setEconomy_fare(result.getDouble(7));
				bean.setBusiness_seats(result.getInt(8));
				bean.setEconomy_seats(result.getInt(9));
				bean.setDeptDate(result.getDate(10));
				bean.setArriveDate(result.getDate(11));
				bean.setArriveTime(result.getString(12));
				bean.setDeptTime(result.getString(13));
				bean.setRemainingBusSeats(result.getInt(14));
				bean.setRemainingEcoSeats(result.getInt(15));
				System.out.println(bean);
			}
			else
			{
				throw new AirlineException("No Such Flight Exist");
			}
			
		}
		
		catch(Exception e)
		{
			throw new AirlineException(e.getMessage());
		}
		
		return bean;
	}
	
	/*
	 * defining method, used to Add new flight information by admin
	 */
	@Override
	public boolean insertFlightInfo(FlightBean bean) throws AirlineException {
		// TODO Auto-generated method stub
		boolean flag = false;
		String insertFInfo = "INSERT INTO FLIGHT_INFO VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		try {
			PreparedStatement pstmt = con.prepareStatement(insertFInfo);
			pstmt.setString(1, bean.getFlightNum());
			pstmt.setString(2, bean.getAirlineName());
			pstmt.setInt(3, Integer.parseInt(bean.getAirport_zip()));
			pstmt.setString(4, bean.getSource());
			pstmt.setString(5, bean.getDestination());
			pstmt.setDouble(6, bean.getBusiness_fare());
			pstmt.setDouble(7, bean.getEconomy_fare());
			pstmt.setInt(8, bean.getBusiness_seats());
			pstmt.setInt(9, bean.getEconomy_seats());
			pstmt.setDate(10, bean.getDeptDate());
			pstmt.setDate(11, bean.getArriveDate());
			pstmt.setString(12, bean.getArriveTime());
			pstmt.setString(13, bean.getDeptTime());
			pstmt.setInt(14, bean.getBusiness_seats());
			pstmt.setInt(15, bean.getEconomy_seats());
			
			int row = pstmt.executeUpdate();
			if (row != 0) {
				flag = true;
			}
			else
				throw new AirlineException("Sorry Unable to insert.. Try Again..");

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new AirlineException("Exception while inserting flight info");

		}
		return flag;
	}
	
	//method used to get sequence number
	public int getSequence() throws AirlineException
	{
		int sequence=0;
		String sql="SELECT pnr_seq.nextval FROM DUAL";
		Statement stmt;
		try {
			stmt = con.createStatement();
			ResultSet result=stmt.executeQuery(sql);
			if(result.next())
			{
				sequence=result.getInt(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new AirlineException(e.getMessage());
		}
		return sequence;
	}
	
	/*
	 * defining method, used to fetch all flight information based on date of
	 * journey entered by admin
	 */
	@Override
	public ArrayList<FlightBean> generateFlightList(LocalDate dateJourney)
			throws AirlineException {
		// TODO Auto-generated method stub
		ArrayList<FlightBean> flightList = new ArrayList<FlightBean>();
		try
		{
			String sql = "SELECT * FROM FLIGHT_INFO WHERE SCH_DEPRT_TIME like ?";
			PreparedStatement pstmt = con.prepareStatement(sql);
			Date date=Date.valueOf(dateJourney);
			//pstmt.setString(1,"%"+Date.valueOf(dateJourney)+"%");
			pstmt.setString(1, "%"+date+"%");
			ResultSet result = pstmt.executeQuery();
			while(result.next())
			{
				FlightBean flightBean = new FlightBean();
				flightBean.setFlightNum(result.getString(1));
				flightBean.setAirlineName(result.getString(2));
				flightBean.setAirport_zip(result.getString(3));
				flightBean.setSource(result.getString(4));
				flightBean.setDestination(result.getString(5));
				flightBean.setBusiness_fare(result.getInt(6));
				flightBean.setEconomy_fare(result.getInt(7));
				flightBean.setBusiness_seats(result.getInt(8));
				flightBean.setEconomy_seats(result.getInt(9));
				flightBean.setDeptDate(result.getDate(10));
				flightBean.setArriveDate(result.getDate(11));
				flightBean.setArriveTime(result.getString(12));
				flightBean.setDeptTime(result.getString(13));
				//flightBean.setArriveTime((result.getTime(8)).toLocalTime());
				//flightBean.setDeptTime(result.getTime(9).toLocalTime());
				flightList.add(flightBean);	
				//System.out.println(flightList.size());
			}
			
		}
		catch(Exception e)
		{
			throw new AirlineException(e.getMessage());
		}
		return flightList;
	}

	/*
	 * defining method, used to fetch all the passengers list based on flight
	 * number by admin
	 */
	@Override
	public ArrayList<BookingBean> fetchPassengerList(String flightNum)
			throws AirlineException {
		// TODO Auto-generated method stub
		
		ArrayList<BookingBean> passengerList = new ArrayList<BookingBean>();
		
		String sql = "SELECT * FROM BOOKING_INFO WHERE FLIGHT_NUM=?";
		PreparedStatement pstmt;
		try {
			
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, flightNum);
			
			ResultSet result = pstmt.executeQuery();
			
			while(result.next())
			{
				BookingBean bean = new BookingBean();
				bean.setPnr(result.getInt(1));
				bean.setFlightNo(result.getString(2));
				bean.setCustId(Integer.parseInt(result.getString(3)));
				bean.setCustMobile(result.getString(4));
				bean.setCustMail(result.getString(5));
				bean.setPassengerNum(result.getInt(6));
				bean.setClassType(result.getString(7));
				bean.setTotalFare(result.getDouble(8));
				bean.setSource(result.getString(9));
				bean.setDest(result.getString(10));
				bean.setDateOfJourney(result.getDate(11));
				bean.setBookTime(result.getTime(12).toLocalTime());
				
				passengerList.add(bean);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new AirlineException(e.getMessage());
		}
		
		
		return passengerList;
	}
	

}

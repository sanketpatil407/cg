package com.cg.airreservation.service;

/**
 * <AirLine Reservation System>
 * Interface for declaring service class methods i.e AirlineServiceImpl class 
 */
import java.time.LocalDate;
import java.util.ArrayList;

import com.cg.airreservation.dao.AirlineDao;
import com.cg.airreservation.dto.BookingBean;
import com.cg.airreservation.dto.CustomerInfoBean;
import com.cg.airreservation.dto.FlightBean;
import com.cg.airreservation.exception.AirlineException;

public interface AirlineService {

	// This method used to add new flight in the system by Admin
	public boolean insertFlightInfo(FlightBean bean) throws AirlineException;

	// This method used to book tickets using flight information by Customer
	public boolean insertPassengerInfo(BookingBean bean, FlightBean fBean)
			throws AirlineException;

	// This method used to register a new Customer
	public boolean insertdetails(CustomerInfoBean bean) throws AirlineException;

	// This method used to fetch flight info based on date entered by customer

	public ArrayList<FlightBean> searchFlight(LocalDate dateJourney)
			throws AirlineException;

	// This method used to authenticate customer,admin and executive
	public CustomerInfoBean checkcredentials(String email, String password)
			throws AirlineException;

	// this method is used to calculate total amount for booked tickets
	public double calFare(BookingBean bean, FlightBean fBean)
			throws AirlineException;

	// this method is used to check seat availability by executive
	public FlightBean flightOccupancyDetails(String flight_num)
			throws AirlineException;

	// This method used to fetch flight info based on date entered by admin
	public ArrayList<FlightBean> generateFlightList(LocalDate dateJourney)
			throws AirlineException;

	// this method is used to fetch all the passengers in a flight by admin
	public ArrayList<BookingBean> fetchPassengerList(String flightNum)
			throws AirlineException;

	// this is used to validate customer name
	boolean validateUser(String name);

	// this is used to validate email id of customer
	boolean validateEmail(String email);

	// this is used to validate customer mobile number
	boolean validateMobile(String mobile);

	// this is used to validate date
	public boolean validateDate(LocalDate date);

	// this is used to validate customer password
	public boolean validatePass(String password);

	// this is used to check date pattern
	public boolean checkDate(String date);

	public void setDao(AirlineDao dao);
	
}

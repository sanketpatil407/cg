declare 

ctr number:=1;
begin
loop -- similar to do while loop 
dbms_output.put_line(ctr);
ctr:=ctr+1;
exit when ctr=5;
end loop;

end;
/
--if else in pl sql 
--accept age from user and determine whther user is eligible to vote 


begin





end;
/


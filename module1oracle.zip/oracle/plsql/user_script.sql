drop table users cascade constraints;
CREATE TABLE Users (user_id NUMBER PRIMARY KEY, first_name vARCHAR2(20), 
last_name VARCHAR2(20), date_of_registration DATE, 
interested_technology VARCHAR2(50), email_id VARCHAR2(20));
INSERT INTO users VALUES(101,'Preetham','K','10-JAN-2010','JAVA', 'preetham.k@igate.com');
INSERT INTO users VALUES(102,'Aakash','M','10-NOV-2012','.Net', 'akash.m@igate.com');
INSERT INTO users VALUES(103,'Kishore','J','19-DEC-2012','JAVA', 'kishore.j@igate.com');
INSERT INTO users VALUES(104,'Reena','A','23-JUN-2013','JAVA', 'reena.a@igate.com');
INSERT INTO users VALUES(105,'Kailash','B','05-FEB-2012','.Net', 'kailash.b@igate.com');
INSERT INTO users VALUES(106,'Sahana','R','18-NOV-2010','MF', 'sahana.r@igate.com');
INSERT INTO users VALUES(107,'Keerthana','S','25-JUL-2011','Systems', 'keertha.s@igate.com');
CREATE SEQUENCE  userid_seq START WITH 108;
/

package com.cg.airreservation.dbutil;

/**
 * <AirLine Reservation System>
 *	this class contain all the required information to establish connection with database
 */
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

public class DBUtil {

	static Properties prop = new Properties();

	// declaring static variables
	static String driver;
	static String user;
	static String pass;
	static String url;
	static Connection con;

	// Static block
	static {
		try {

			// To load and Fetch driver details from given file
			prop.load(new FileInputStream("jdbc.properties"));
			driver = prop.getProperty("driver");
			url = prop.getProperty("url");
			user = prop.getProperty("user");
			pass = prop.getProperty("pass");
			Class.forName(driver);
			con = DriverManager.getConnection(url, user, pass);

		} catch (FileNotFoundException e) {

			System.out.println(e.getMessage());
		} catch (Exception e) {

			System.out.println(e.getMessage());
		}
	}

	// method
	public static Connection getConnection() {
		return con;
	}

}

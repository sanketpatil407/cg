package com.cg.airreservation.test;

import static org.junit.Assert.*;

import java.sql.Date;
import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

import oracle.net.aso.f;

import org.junit.Before;
import org.junit.Test;

import com.cg.airreservation.dao.AirlineDao;
import com.cg.airreservation.dao.AirlineDaoImpl;
import com.cg.airreservation.dao.IDaoExecutive;
import com.cg.airreservation.dto.BookingBean;
import com.cg.airreservation.dto.CustomerInfoBean;
import com.cg.airreservation.dto.FlightBean;
import com.cg.airreservation.exception.AirlineException;
import com.cg.airreservation.service.AirlineService;
import com.cg.airreservation.service.AirlineServiceImpl;

public class AirlineReservationTestCase {
	
	AirlineService service;
	AirlineDao dao;
	IDaoExecutive dao1;
	
	BookingBean book = new BookingBean();
	CustomerInfoBean cust = new CustomerInfoBean();
	FlightBean flight = new FlightBean();
	
	@Before
	public void init(){
		service = new AirlineServiceImpl();
		dao = new AirlineDaoImpl();
		service.setDao(dao);
	}

	@Test
	public void testInsertDetails() throws AirlineException {
		
		cust.setCustId(100000);
		cust.setCustName("Allen");
		cust.setPassword("A@123fghj");
		cust.setMobileno("9856325632");
		cust.setEmail("abc@gmail.com");
		cust.setGender("male");
		cust.setDatOfBirth(LocalDate.now());

		assertEquals(true, service.insertdetails(cust));
		
	}
	
	@Test
	public void test1InsertDetails() throws AirlineException {
		
		cust.setCustId(100000);
		cust.setCustName("Allen");
		cust.setPassword("A@123fghj");
		cust.setMobileno("9856325632");
		cust.setEmail("abc@gmail.com");
		cust.setGender("male");
		cust.setDatOfBirth(LocalDate.now());
		
			assertNotEquals(true, service.insertdetails(cust));
		
		
	}
	
	@Test
	public void testCheckCredentials() throws AirlineException {
		cust.setCustId(10);
		cust.setCustName("allen");
		cust.setPassword("123fghj");
		cust.setMobileno("3255632");
		cust.setEmail("5@gmail.com");
		cust.setGender("m");
		cust.setDatOfBirth(LocalDate.now());
	
		assertEquals(true, service.insertdetails(cust));
			
			
	}
	
	@Test
	public void test1CheckCredentials() throws AirlineException {
		cust.setCustId(10);
		cust.setCustName("allen");
		cust.setPassword("123fghj");
		cust.setMobileno("3255632");
		cust.setEmail("5@gmail.com");
		cust.setGender("m");
		cust.setDatOfBirth(LocalDate.now());
	
		assertEquals(false, service.insertdetails(cust));
			
			
	}
	
	@Test
	public void testSearchFlight() throws AirlineException {
		
		flight.setFlightNum("53563");
		flight.setAirlineName("Jet");
		flight.setAirport_zip("421004");
		flight.setSource("Mumbai");
		flight.setDestination("Pune");
		flight.setBusiness_fare(25025);
		flight.setEconomy_fare(12566);
		flight.setBusiness_seats(200);
		flight.setEconomy_seats(600);
		flight.setArriveDate(Date.valueOf(LocalDate.now()));
		flight.setDeptDate(Date.valueOf(LocalDate.now()));
		flight.setArriveTime("05:25:23");
		flight.setDeptTime("14:22:21");
		flight.setRemainingBusSeats(2);
		flight.setRemainingEcoSeats(5);
		
		
		String input = "17/06/2017";
		LocalDate date;
		DateTimeFormatter format;
		format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		date = LocalDate.parse(input, format);
		assertNotNull(service.searchFlight(date));
		
	
	}
	
	@Test
	public void test1SearchFlight() throws AirlineException {
		
		flight.setFlightNum("53563");
		flight.setAirlineName("Jet");
		flight.setAirport_zip("421004");
		flight.setSource("Mumbai");
		flight.setDestination("Pune");
		flight.setBusiness_fare(25025);
		flight.setEconomy_fare(12566);
		flight.setBusiness_seats(200);
		flight.setEconomy_seats(600);
		flight.setArriveDate(Date.valueOf(LocalDate.now()));
		flight.setDeptDate(Date.valueOf(LocalDate.now()));
		flight.setArriveTime("05:25:23");
		flight.setDeptTime("14:22:21");
		flight.setRemainingBusSeats(2);
		flight.setRemainingEcoSeats(5);
		
		
		String input = "17/06/2017";
		LocalDate date;
		DateTimeFormatter format;
		format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		date = LocalDate.parse(input, format);
		assertNull(service.searchFlight(date));
		
	
	}
	
	@Test
	public void testInsertPassengerInfo() throws AirlineException{
		book.setPnr(1006);
		book.setFlightNo("IA435");
		book.setCustId(111);
		book.setCustMobile("8596589656");
		book.setCustMail("abc@gmail.com");
		book.setPassengerNum(6545);
		book.setClassType("a");
		book.setTotalFare(654564);
		book.setSource("Mumbai");
		book.setDest("Pune");
		
		
		String input = "06/06/2017";
		LocalDate date;
		DateTimeFormatter format;
		format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		date = LocalDate.parse(input, format);
		book.setDateOfJourney(Date.valueOf(date));
		
		String input1 = "03:45:23";
		LocalTime now;
		DateTimeFormatter format1;
		format1=DateTimeFormatter.ofPattern("HH:mm:ss");
		now=LocalTime.parse(input1, format1);
		book.setBookTime(now);
		
		assertEquals(true, service.insertPassengerInfo(book, flight));
	}
	
	@Test
	public void test1InsertPassengerInfo() throws AirlineException{
		book.setPnr(1006);
		book.setFlightNo("IA435");
		book.setCustId(111);
		book.setCustMobile("8596589656");
		book.setCustMail("abc@gmail.com");
		book.setPassengerNum(6545);
		book.setClassType("a");
		book.setTotalFare(654564);
		book.setSource("Mumbai");
		book.setDest("Pune");
		
		
		String input = "06/06/2017";
		LocalDate date;
		DateTimeFormatter format;
		format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		date = LocalDate.parse(input, format);
		book.setDateOfJourney(Date.valueOf(date));
		
		String input1 = "03:45:23";
		LocalTime now;
		DateTimeFormatter format1;
		format1=DateTimeFormatter.ofPattern("HH:mm:ss");
		now=LocalTime.parse(input1, format1);
		book.setBookTime(now);
		
		assertEquals(false, service.insertPassengerInfo(book, flight));
	}
       
	@Test
	public void testFlightOccupancyDetails() throws AirlineException{
		flight.setFlightNum("IA76");
		flight.setAirlineName("SpiceJet");
		flight.setAirport_zip("345001");
		flight.setSource("Delhi");
		flight.setDestination("Pune");
		flight.setBusiness_fare(1700);
		flight.setEconomy_fare(1300);
		flight.setBusiness_seats(60);
		flight.setEconomy_seats(80);
		flight.setArriveDate(Date.valueOf(LocalDate.now()));
		flight.setDeptDate(Date.valueOf(LocalDate.now()));
		flight.setArriveTime("05:25:23");
		flight.setDeptTime("14:22:21");
		flight.setRemainingBusSeats(50);
		flight.setRemainingEcoSeats(63);
		
		
		assertNotNull(service.flightOccupancyDetails("IA76"));
		
	}
	
	@Test
	public void test1FlightOccupancyDetails() throws AirlineException{
		flight.setFlightNum("IA76");
		flight.setAirlineName("SpiceJet");
		flight.setAirport_zip("345001");
		flight.setSource("Delhi");
		flight.setDestination("Pune");
		flight.setBusiness_fare(1700);
		flight.setEconomy_fare(1300);
		flight.setBusiness_seats(60);
		flight.setEconomy_seats(80);
		flight.setArriveDate(Date.valueOf(LocalDate.now()));
		flight.setDeptDate(Date.valueOf(LocalDate.now()));
		flight.setArriveTime("05:25:23");
		flight.setDeptTime("14:22:21");
		flight.setRemainingBusSeats(50);
		flight.setRemainingEcoSeats(63);
		
		
		assertNull(service.flightOccupancyDetails("IA76"));
		
	}
	
	@Test
	public void testInsertFlightInfo() throws AirlineException{
			flight.setFlightNum("sfs");
			flight.setAirlineName("SpiceJet");
			flight.setAirport_zip("345001");
			flight.setSource("Delhi");
			flight.setDestination("Pune");
			flight.setBusiness_fare(1700);
			flight.setEconomy_fare(1300);
			flight.setBusiness_seats(60);
			flight.setEconomy_seats(80);
			flight.setArriveDate(Date.valueOf(LocalDate.now()));
			flight.setDeptDate(Date.valueOf(LocalDate.now()));
			flight.setArriveTime("05:25:23");
			flight.setDeptTime("14:22:21");
			
			
			assertEquals(true, service.insertFlightInfo(flight));
		
	}
	
	@Test
	public void testGenerateFlightList() throws AirlineException{
		flight.setFlightNum("sfsd6");
		flight.setAirlineName("SpiceJet");
		flight.setAirport_zip("345001");
		flight.setSource("Delhi");
		flight.setDestination("Pune");
		flight.setBusiness_fare(1700);
		flight.setEconomy_fare(1300);
		flight.setBusiness_seats(60);
		flight.setEconomy_seats(80);
		flight.setArriveDate(Date.valueOf(LocalDate.now()));
		flight.setDeptDate(Date.valueOf(LocalDate.now()));
		flight.setArriveTime("05:25:23");
		flight.setDeptTime("14:22:21");
		
		String input = "17/06/2017";
		LocalDate date;
		DateTimeFormatter format;
		format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		date = LocalDate.parse(input, format);
		assertNotNull(service.generateFlightList(date));
	}
	
	@Test
	public void test1GenerateFlightList() throws AirlineException{
		flight.setFlightNum("sfsd6");
		flight.setAirlineName("SpiceJet");
		flight.setAirport_zip("345001");
		flight.setSource("Delhi");
		flight.setDestination("Pune");
		flight.setBusiness_fare(1700);
		flight.setEconomy_fare(1300);
		flight.setBusiness_seats(60);
		flight.setEconomy_seats(80);
		flight.setArriveDate(Date.valueOf(LocalDate.now()));
		flight.setDeptDate(Date.valueOf(LocalDate.now()));
		flight.setArriveTime("05:25:23");
		flight.setDeptTime("14:22:21");
		
		String input = "17/06/2017";
		LocalDate date;
		DateTimeFormatter format;
		format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		date = LocalDate.parse(input, format);
		assertNull(service.generateFlightList(date));
	}
	
	
	@Test
	public void testFetchPassengerList() throws AirlineException{
		book.setPnr(1006);
		book.setFlightNo("IA435");
		book.setCustId(111);
		book.setCustMobile("8596589656");
		book.setCustMail("abc@gmail.com");
		book.setPassengerNum(6545);
		book.setClassType("a");
		book.setTotalFare(654564);
		book.setSource("Mumbai");
		book.setDest("Pune");
		
		
		String input = "06/06/2017";
		LocalDate date1;
		DateTimeFormatter format;
		format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		date1 = LocalDate.parse(input, format);
		book.setDateOfJourney(Date.valueOf(date1));
		
		String input1 = "03:45:23";
		LocalTime now;
		DateTimeFormatter format1;
		format1=DateTimeFormatter.ofPattern("HH:mm:ss");
		now=LocalTime.parse(input1, format1);
		book.setBookTime(now);
		
		assertNotNull(service.fetchPassengerList("IA435"));
		
	}
	
	@Test
	public void test1FetchPassengerList() throws AirlineException{
		book.setPnr(1006);
		book.setFlightNo("IA435");
		book.setCustId(111);
		book.setCustMobile("8596589656");
		book.setCustMail("abc@gmail.com");
		book.setPassengerNum(6545);
		book.setClassType("a");
		book.setTotalFare(654564);
		book.setSource("Mumbai");
		book.setDest("Pune");
		
		
		String input = "06/06/2017";
		LocalDate date1;
		DateTimeFormatter format;
		format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		date1 = LocalDate.parse(input, format);
		book.setDateOfJourney(Date.valueOf(date1));
		
		String input1 = "03:45:23";
		LocalTime now;
		DateTimeFormatter format1;
		format1=DateTimeFormatter.ofPattern("HH:mm:ss");
		now=LocalTime.parse(input1, format1);
		book.setBookTime(now);
		
		assertNull(service.fetchPassengerList("IA435"));
		
	}
}

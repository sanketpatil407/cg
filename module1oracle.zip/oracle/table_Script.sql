DROP TABLE product_order;
DROP TABLE product;
DROP TABLE customer;

CREATE TABLE product(
product_id NUMBER(4) PRIMARY KEY,
product_description VARCHAR2(20),
price NUMBER(9,2)
);

INSERT INTO product VALUES(1001,'Pencil Box',40);
INSERT INTO product VALUES(1002,'Cello Pen Box',80);
INSERT INTO product VALUES(1003,'Eraser Box',20);
INSERT INTO product VALUES(1004,'Drawing Pin Box',25);

CREATE TABLE customer(
cust_id NUMBER(4) PRIMARY KEY,
cust_name VARCHAR2(20),
email VARCHAR2(40),
mobile NUMBER(10),
address VARCHAR2(50)
);

INSERT INTO customer VALUES(2001,'Rohini','rohini@igate.com',8989898989,
'Pune');
INSERT INTO customer VALUES(2002,'Satyen','satyen@igate.com',8765457899,
'Mumbai');
INSERT INTO customer VALUES(2003, 'Rashmi', 'rashmi@igate.com', 9867563423, 'Bangalore');
INSERT INTO customer VALUES(2004,'Bala','bala@igate.com',7856432311,'Chennai');

CREATE TABLE product_order(
ord_no NUMBER(4) PRIMARY KEY,
product_id NUMBER(4) REFERENCES product(product_id),
cust_id NUMBER(4) REFERENCES customer(cust_id),
quantity NUMBER(3),
order_date DATE,
);



INSERT INTO product_order VALUES(3001,1001,2001,35,'26-JUN-14');
INSERT INTO product_order VALUES(3002,1002,2001,25,'13-MAY-14');
INSERT INTO product_order VALUES(3003,1001,2002,45,'20-FEB-14');
INSERT INTO product_order VALUES(3004,1003,2001,20,'26-JUN-14');
INSERT INTO product_order VALUES(3005,1001,2003,77,'17-AUG-14');
INSERT INTO product_order VALUES(3006,1004,2001,88,'10-JUL-14');
COMMIT;

CREATE SEQUENCE ord_no START WITH 3007;

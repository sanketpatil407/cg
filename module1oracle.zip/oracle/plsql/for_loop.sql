begin
for index1 in 1 .. 10 -- loop index need not be declared 
loop
	dbms_output.put_line(index1);
end loop;
end;
/



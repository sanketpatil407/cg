package com.cg.airreservation.service;

import java.time.LocalDate;
import java.util.ArrayList;

import com.cg.airreservation.dto.AirportBean;
import com.cg.airreservation.dto.BookingBean;
import com.cg.airreservation.dto.FlightBean;
import com.cg.airreservation.exception.AirlineException;

public interface IExecutiveService {

	
	// This method used to add new flight in the system by Admin
		public boolean insertFlightInfo(FlightBean bean) throws AirlineException;
		
		// this method is used to check seat availability by executive and admin
		public FlightBean flightOccupancyDetails(String flight_num)
				throws AirlineException;

		// This method used to fetch flight info based on date entered by admin
		public ArrayList<FlightBean> generateFlightList(LocalDate dateJourney)
				throws AirlineException;

		// this method is used to fetch all the passengers in a flight by admin
		public ArrayList<BookingBean> fetchPassengerList(String flightNum)
				throws AirlineException;

		//this method is used to validate date of journey
		public boolean validateDate(LocalDate date);
		
		public boolean validateSource(String source);
		
		public ArrayList<AirportBean> fetchAirportList() throws AirlineException;
		public boolean validateTime(String time);
		public boolean validateArrivalDate(LocalDate dept,LocalDate arrival);
}

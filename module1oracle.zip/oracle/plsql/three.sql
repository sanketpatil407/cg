declare

--this block or section is optional
--use it for variable declarations
--int num1; -- c, java 

num1 number; -- default value stored is null 


begin  -- compulsory


num1:=10 ; --assignment operator is :=
--no increment decrement operators



dbms_output.put_line('value in num1 is :' || num1);

end; 
/ 














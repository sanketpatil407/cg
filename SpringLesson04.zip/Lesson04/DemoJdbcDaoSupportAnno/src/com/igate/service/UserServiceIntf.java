package com.igate.service;

import java.util.List;

import com.igate.bean.User;

public interface UserServiceIntf {
	public List<User> displayUsers();

}

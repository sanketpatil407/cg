package com.cg.airreservation.service;

/**
 * <AirLine Reservation System>
 * class for implementing service interface methods i.e AirlineService methods 
 */
import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;

import com.cg.airreservation.dao.AirlineDao;
import com.cg.airreservation.dao.AirlineDaoImpl;
import com.cg.airreservation.dao.DaoExecutiveImpl;
import com.cg.airreservation.dao.IDaoExecutive;
import com.cg.airreservation.dto.BookingBean;
import com.cg.airreservation.dto.CustomerInfoBean;
import com.cg.airreservation.dto.FlightBean;
import com.cg.airreservation.exception.AirlineException;

public class AirlineServiceImpl implements AirlineService {

	// declaring variables
	AirlineDao dao;
	IDaoExecutive daoExecutive;

	// default constructor
	public AirlineServiceImpl() {
		dao = new AirlineDaoImpl();
		daoExecutive = new DaoExecutiveImpl();
	}

	// This method definition used to add new flight in the system by Admin
	@Override
	public boolean insertFlightInfo(FlightBean bean) throws AirlineException {
		// TODO Auto-generated method stub
		return daoExecutive.insertFlightInfo(bean);
	}

	/*
	 * This method definition used to book tickets using flight information by
	 * Customer
	 */
	@Override
	public boolean insertPassengerInfo(BookingBean bean, FlightBean fBean)
			throws AirlineException {
		// TODO Auto-generated method stub
		return dao.insertPassengerInfo(bean, fBean);
	}

	/*
	 * this method definition is used to calculate total amount for booked
	 * tickets
	 */
	@Override
	public double calFare(BookingBean bean, FlightBean fBean)
			throws AirlineException {

		return dao.calFare(bean, fBean);
	}

	// This method definition used to register a new Customer
	@Override
	public boolean insertdetails(CustomerInfoBean bean) throws AirlineException {
		// TODO Auto-generated method stub
		return dao.insertdetails(bean);
	}

	// This method definition used to authenticate customer,admin and executive
	@Override
	public CustomerInfoBean checkcredentials(String email, String password)
			throws AirlineException {
		// TODO Auto-generated method stub
		return dao.checkcredentials(email, password);
	}

	/*
	 * This method definition used to fetch flight info based on date entered by
	 * customer
	 */
	@Override
	public ArrayList<FlightBean> searchFlight(LocalDate dateJourney)
			throws AirlineException {
		// TODO Auto-generated method stub
		return dao.searchFlight(dateJourney);
	}

	// this method definition is used to check seat availability by executive
	@Override
	public FlightBean flightOccupancyDetails(String flight_num)
			throws AirlineException {
		// TODO Auto-generated method stub
		return daoExecutive.flightOccupancyDetails(flight_num);
	}

	/*
	 * This method definition used to fetch flight info based on date entered by
	 * admin
	 */
	@Override
	public ArrayList<FlightBean> generateFlightList(LocalDate dateJourney)
			throws AirlineException {
		// TODO Auto-generated method stub
		return daoExecutive.generateFlightList(dateJourney);
	}

	/*
	 * this method definition is used to fetch all the passengers in a flight by
	 * admin
	 */
	@Override
	public ArrayList<BookingBean> fetchPassengerList(String flightNum)
			throws AirlineException {
		// TODO Auto-generated method stub
		return daoExecutive.fetchPassengerList(flightNum);
	}

	// this is used to validate customer name
	@Override
	public boolean validateUser(String name) {
		// TODO Auto-generated method stub
		return (name.matches("^[A-Z]{1}[a-zA-Z\\s]{1,49}$"));
	}

	// this is used to validate email id of customer
	@Override
	public boolean validateEmail(String email) {
		// TODO Auto-generated method stub
		return email
				.matches("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");
	}

	// this is used to validate customer mobile number
	@Override
	public boolean validateMobile(String mobile) {
		// TODO Auto-generated method stub
		return mobile.matches("[7-9]{1}[0-9]{9}");
	}

	// this is used to validate date
	@Override
	public boolean validateDate(LocalDate date) {
		// TODO Auto-generated method stub
		LocalDate today = LocalDate.now();
		Period diff = date.until(today);

		if (diff.getDays() < 0 || diff.getMonths() < 0 || diff.getYears() < 0) {

			return false;
		}

		if (diff.getDays() <= 0 && diff.getMonths() <= 0
				&& diff.getYears() <= 0) {

			return false;
		}

		return true;
	}

	// this is used to validate customer password
	@Override
	public boolean validatePass(String password) {
		// TODO Auto-generated method stub

		return password
				.matches("^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+_])(?=\\S+$).{8,15}$");

	}

	// this is used to check date pattern
	@Override
	public boolean checkDate(String date) {
		// TODO Auto-generated method stub
		return date
				.matches("(0[1-9]|1[0-9]|2[0-9]|3[01]).(0[1-9|1[012]].[0-9]{4})");
	}

	@Override
	public void setDao(AirlineDao dao) {
		// TODO Auto-generated method stub
		this.dao = dao;
	}

}
